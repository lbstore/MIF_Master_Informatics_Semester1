@javax.jdo.annotations.PersistenceCapable

public abstract class Person {
	
	String name;

	public String toString() {
		return name;
	}
}